# Simple magic 8 ball app to show as a PWA

1. run with live server
2. deploy to github pages

[Here](https://medium.com/james-johnson/a-simple-progressive-web-app-tutorial-f9708e5f2605) is a link to a tutorial that has the rest of the steps.